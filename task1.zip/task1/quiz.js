const questions = [
    {
        question: "What is the capital of France?",
        options: [
            { image: "imagesberlin.jpg", answer: "Berlin" },
            { image: "imagesmadrid.jpg", answer: "Madrid" },
            { image: "imagesparis.jpg", answer: "Paris" },
            { image: "imagesrome.jpg", answer: "Rome" }
        ],
        correctAnswer: "Paris"
    },
    {
        question: "Which programming language is used for web development?",
        options: [
            { image: "imagespython.jpg", answer: "Python" },
            { image: "imagesjava.jpg", answer: "Java" },
            { image: "imagesjavascript.jpg", answer: "JavaScript" },
            { image: "imagescsharp.jpg", answer: "C#" }
        ],
        correctAnswer: "JavaScript"
    },
    {
        question: "What is the square root of 16?",
        options: [
            { image: "imagestwo.png", answer: "2" },
            { image: "imagesfour.png", answer: "4" },
            { image: "imageseight.png", answer: "8" },
            { image: "imagessixteen.png", answer: "16" }
        ],
        correctAnswer: "4"
    }
];

let currentQuestionIndex = 0;
let score = 0;
let totalQuestions = questions.length;
let progressBar = document.getElementById("progress-bar");

function loadQuestion() {
    const questionContainer = document.getElementById("question-container");
    const optionsContainer = document.getElementById("options-container");
    const feedbackContainer = document.getElementById("feedback");
    const questionNumber = document.getElementById("question-number");

    const question = questions[currentQuestionIndex];
    questionContainer.textContent = question.question;
    questionNumber.textContent = `Question ${currentQuestionIndex + 1} of ${totalQuestions}`;

    optionsContainer.innerHTML = "";
    question.options.forEach(option => {
        const optionDiv = document.createElement("div");
        optionDiv.classList.add("option");
        
        const img = document.createElement("img");
        img.src = option.image;
        img.alt = option.answer;
        
        const optionText = document.createElement("div");
        optionText.classList.add("option-text");
        optionText.textContent = option.answer;
        
        optionDiv.appendChild(img);
        optionDiv.appendChild(optionText);

        optionDiv.onclick = () => checkAnswer(option.answer);
        optionsContainer.appendChild(optionDiv);
    });

    feedbackContainer.textContent = "";
    document.getElementById("next-button").style.display = "none";
    updateProgressBar();
}

function checkAnswer(selectedOption) {
    const feedbackContainer = document.getElementById("feedback");
    const currentQuestion = questions[currentQuestionIndex];

    const options = document.getElementById("options-container").children;
    for (let option of options) {
        option.style.pointerEvents = "none";  // Disable all images after selection
    }

    if (selectedOption === currentQuestion.correctAnswer) {
        score++;
        feedbackContainer.textContent = "Correct! Well done.";
        feedbackContainer.style.color = "#4CAF50";
        document.querySelectorAll(".option img").forEach(img => {
            if (img.alt === selectedOption) {
                img.style.border = "5px solid #4CAF50";  // Highlight correct answer with green
            }
        });
    } else {
        feedbackContainer.textContent = "Incorrect. Try again!";
        feedbackContainer.style.color = "#f44336";
        document.querySelectorAll(".option img").forEach(img => {
            if (img.alt === currentQuestion.correctAnswer) {
                img.style.border = "5px solid #4CAF50";  // Highlight correct answer with green
            } else if (img.alt === selectedOption) {
                img.style.border = "5px solid #f44336";  // Highlight incorrect answer with red
            }
        });
    }

    document.getElementById("next-button").style.display = "block";
}

function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        displayCompletionMessage();
    }
}

function updateProgressBar() {
    let progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;
    progressBar.style.width = progress + "%";
}

function displayCompletionMessage() {
    const completionMessage = document.getElementById("completion-message");
    completionMessage.textContent = `Quiz Complete! Your score is: ${score} out of ${questions.length}`;
    document.getElementById("score").textContent = `Your Final Score: ${score}`;
    document.getElementById("next-button").disabled = true;
}

// Initialize the quiz
loadQuestion();
